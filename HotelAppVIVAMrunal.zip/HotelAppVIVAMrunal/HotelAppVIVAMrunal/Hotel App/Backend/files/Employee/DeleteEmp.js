const mysql = require('mysql');
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '1234',
    database: 'Sayura-Beach-Hotel'
});
connection.connect((err) => {
    if (err) throw err;
    console.log('Connected delete');
});

module.exports = function (app){
    app.get('/DeleteEmp', function (req, res) {
        res.header("Access-Control-Allow-Origin", "*");
        res.header("Access-Control-Allow-Headers", "Origin,X-Requested-With,Content-Type,Accept");
        res.header('Access-Control-Allow-Methods', 'DELETE,PUT');
        connection.query('DELETE FROM employee WHERE id = "'+req.query.id+'"',(err,rows) =>{
        console.log('Done',err);
            
        });
   
    });
}