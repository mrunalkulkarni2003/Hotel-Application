import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-equipment',
  templateUrl: './view-equipment.component.html',
  styleUrls: ['./view-equipment.component.css']
})
export class ViewEquipmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
