import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-daily-shift',
  templateUrl: './view-daily-shift.component.html',
  styleUrls: ['./view-daily-shift.component.css']
})
export class ViewDailyShiftComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
