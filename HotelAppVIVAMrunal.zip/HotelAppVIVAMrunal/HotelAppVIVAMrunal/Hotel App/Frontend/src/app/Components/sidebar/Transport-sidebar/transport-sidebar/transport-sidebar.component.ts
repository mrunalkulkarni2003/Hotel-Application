import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transport-sidebar',
  templateUrl: './transport-sidebar.component.html',
  styleUrls: ['./transport-sidebar.component.css']
})
export class TransportSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
